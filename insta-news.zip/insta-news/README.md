# 인스타 뉴스 자동화 (완전 자동)

흐름: 매일 08:00 뉴스 수집 → Claude 요약 → 카드뉴스 영상(+음악) 생성 → GitHub에 커밋 →
Instagram 릴스로 즉시 자동 업로드. 사람 승인 단계 없음.

## 설정 순서
1. **GitHub**: **public** 저장소를 만들고 이 폴더를 올립니다(기본 브랜치 main).
   public이어야 `raw.githubusercontent.com` 주소로 인스타가 영상을 읽어갈 수 있어요.
2. Settings → Secrets and variables → Actions 에 등록:
   - `ANTHROPIC_API_KEY`
   - `IG_USER_ID`, `IG_ACCESS_TOKEN` (인스타 비즈니스 계정 + Meta 앱에서 발급, 아래 6번 참고)
   - `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` (선택 — 업로드 성공/실패 알림만 받고 싶을 때)
3. **음악**: 저작권 없는 mp3를 `music/` 폴더에 넣습니다(Pixabay Music, YouTube 오디오 라이브러리,
   Free Music Archive의 CC0/상업적 이용 가능 곡만). 여러 곡을 넣으면 매번 랜덤으로 골라 씁니다.
4. RSS 출처, 기사 개수, 슬라이드 길이는 `generate.py` 맨 위 설정에서 바꿀 수 있어요.
5. Actions 탭 → **auto-news-to-instagram** → Run workflow 로 첫 테스트를 돌려보세요.
   실패하면 로그를 확인해 어떤 secret이 빠졌는지 알 수 있어요.
6. **인스타 토큰 발급**: 계정을 비즈니스/크리에이터로 전환하고 Facebook 페이지에 연결 →
   Meta 개발자 앱 생성 → `instagram_content_publish` 권한 토큰과 IG 계정(User) ID 발급.
   토큰은 약 60일마다 만료되니 갱신이 필요합니다.

## 주의할 점
- 사람 검수 없이 바로 올라가므로, 초반에는 `workflow_dispatch`로 수동 실행하며
  결과 영상(`out/*.mp4`)과 캡션을 눈으로 몇 번 확인해보길 권해요.
- Claude에게는 원문을 그대로 베끼지 말고 요약하도록 지시해뒀지만, 오역·오류 가능성은 항상 있습니다.
- Instagram Graph API에는 일일 게시 제한이 있어 하루 한 번 정도면 문제없어요.
