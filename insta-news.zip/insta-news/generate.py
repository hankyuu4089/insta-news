import os, sys, re, json, glob, random, subprocess, datetime
import feedparser, requests
from PIL import Image, ImageDraw, ImageFont
import anthropic

# ===== 설정 =====
FEEDS = {
    "domestic": [("연합뉴스", "https://www.yna.co.kr/rss/news.xml"),
                 ("한겨레", "https://www.hani.co.kr/rss/")],
    "world": [("BBC", "http://feeds.bbci.co.uk/news/world/rss.xml"),
              ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml")],
}
N_DOMESTIC, N_WORLD = 3, 2
SLIDE_SEC = 4
FONT = "/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf"
W, H = 1080, 1920
HASHTAGS = "#뉴스 #오늘의뉴스 #이슈 #카드뉴스"


def collect(category, n, seen):
    per = []
    for src, url in FEEDS[category]:
        try:
            d = feedparser.parse(url)
        except Exception:
            continue
        items = [{"source": src, "title": e.get("title", "").strip(),
                  "desc": re.sub(r"<[^>]+>", "", e.get("summary", "")).strip()[:400],
                  "link": e.get("link", "")}
                 for e in d.entries[:15] if e.get("link") and e.get("link") not in seen]
        per.append(items)
    out = []
    while len(out) < n and any(per):
        for items in per:
            if items and len(out) < n:
                out.append(items.pop(0))
    return out


def summarize(items):
    client = anthropic.Anthropic()
    payload = [{"i": i, "source": x["source"], "title": x["title"], "desc": x["desc"]}
               for i, x in enumerate(items)]
    prompt = ("다음 뉴스 각각을 한국어 카드뉴스용으로 정리해줘. 원문 문장을 그대로 베끼지 말고 사실만 네 말로 요약해. "
              "headline은 22자 이내, summary는 80자 이내 두 문장 이하. 주어진 내용에 없는 사실은 추가하지 마. "
              'JSON 배열만 출력: [{"i":0,"headline":"...","summary":"..."}]\n\n'
              + json.dumps(payload, ensure_ascii=False))
    msg = client.messages.create(model="claude-sonnet-5", max_tokens=2000,
                                 messages=[{"role": "user", "content": prompt}])
    text = re.sub(r"```(?:json)?", "", msg.content[0].text).strip()
    for r in json.loads(text):
        items[r["i"]].update(headline=r["headline"], summary=r["summary"])
    return [x for x in items if "headline" in x]


def wrap(d, text, font, maxw):
    lines, cur = [], ""
    for ch in text:
        if d.textlength(cur + ch, font=font) > maxw:
            lines.append(cur)
            cur = ch.lstrip()
        else:
            cur += ch
    if cur:
        lines.append(cur)
    return lines


def slide(path, tag, head, body, foot):
    img = Image.new("RGB", (W, H), (17, 24, 39))
    d = ImageDraw.Draw(img)
    f_tag, f_head = ImageFont.truetype(FONT, 44), ImageFont.truetype(FONT, 78)
    f_body, f_foot = ImageFont.truetype(FONT, 50), ImageFont.truetype(FONT, 38)
    y = 260
    d.rounded_rectangle((90, y, 90 + d.textlength(tag, font=f_tag) + 60, y + 80), radius=40, fill=(250, 204, 21))
    d.text((120, y + 12), tag, font=f_tag, fill=(17, 24, 39))
    y += 170
    for l in wrap(d, head, f_head, W - 180):
        d.text((90, y), l, font=f_head, fill=(255, 255, 255))
        y += 110
    y += 50
    for l in wrap(d, body, f_body, W - 180):
        d.text((90, y), l, font=f_body, fill=(209, 213, 219))
        y += 78
    d.text((90, H - 260), foot, font=f_foot, fill=(156, 163, 175))
    img.save(path)


def make_video(pngs, out):
    music = [p for e in ("mp3", "m4a", "wav") for p in glob.glob(f"music/*.{e}")]
    with open("slides/list.txt", "w") as f:
        for p in pngs:
            f.write(f"file '{os.path.abspath(p)}'\nduration {SLIDE_SEC}\n")
        f.write(f"file '{os.path.abspath(pngs[-1])}'\n")
    total = SLIDE_SEC * len(pngs)
    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "slides/list.txt"]
    if music:
        cmd += ["-stream_loop", "-1", "-i", random.choice(music)]
    cmd += ["-vf", "fps=30,format=yuv420p", "-c:v", "libx264", "-t", str(total)]
    if music:
        cmd += ["-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "128k",
                "-af", f"afade=t=out:st={total - 2}:d=2"]
    cmd += ["-movflags", "+faststart", out]
    subprocess.run(cmd, check=True)


def build():
    os.makedirs("out", exist_ok=True)
    os.makedirs("slides", exist_ok=True)
    posted = json.load(open("posted.json")) if os.path.exists("posted.json") else []
    items = []
    for cat, n, tag in (("domestic", N_DOMESTIC, "국내"), ("world", N_WORLD, "해외")):
        for x in collect(cat, n, set(posted)):
            x["tag"] = tag
            items.append(x)
    if not items:
        print("새 뉴스 없음")
        return
    items = summarize(items)
    now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9)))
    pid = now.strftime("%Y%m%d-%H%M")
    pngs = ["slides/00.png"]
    slide(pngs[0], "NEWS", "오늘의 뉴스", now.strftime("%Y년 %m월 %d일"), "국내·해외 주요 뉴스 요약")
    for i, x in enumerate(items, 1):
        p = f"slides/{i:02d}.png"
        slide(p, x["tag"], x["headline"], x["summary"], f"출처: {x['source']}")
        pngs.append(p)
    make_video(pngs, f"out/{pid}.mp4")
    sources = ", ".join(sorted({x["source"] for x in items}))
    caption = ("📰 오늘의 뉴스\n\n"
               + "\n\n".join(f"{i}. {x['headline']}\n{x['summary']}" for i, x in enumerate(items, 1))
               + f"\n\n출처: {sources}\n{HASHTAGS}")
    open(f"out/{pid}.txt", "w", encoding="utf-8").write(caption)
    json.dump(items, open(f"out/{pid}.json", "w"), ensure_ascii=False)
    json.dump((posted + [x["link"] for x in items])[-500:], open("posted.json", "w"))
    vids = sorted(glob.glob("out/*.mp4"))
    for v in vids[:-10]:
        for ext in ("mp4", "txt", "json"):
            t = v[:-3] + ext
            if os.path.exists(t):
                os.remove(t)
    open("pending.txt", "w").write(pid)
    return pid


def notify(text):
    """텔레그램 알림은 선택사항. 토큰이 없으면 조용히 건너뜀."""
    tok, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat:
        return
    requests.post(f"https://api.telegram.org/bot{tok}/sendMessage",
                   data={"chat_id": chat, "text": text}, timeout=30)


if __name__ == "__main__":
    if sys.argv[1] == "build":
        build()
